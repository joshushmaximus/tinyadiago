﻿using System;
using System.IO;
using System.Windows.Forms;

namespace org.niffty.ui {
  static class Program {
    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Score score;
      using (var stream = File.OpenRead(Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "prelude.nif"))) {
        score = RiffScore.newInstance(stream);
      }

      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run(new FormMain { Score = score });
    }
  }
}
